========================================================================
Microsoft.Windows.WinMD C++ metadata parsing library
========================================================================

The Microsoft.Windows.WinMD NuGet package provides a pure C++ header metadata parsing library.  
Adding a reference to this package adds the library to the project's additional include directories.  

========================================================================
For more information, visit:
https://github.com/microsoft/winmd/
========================================================================
